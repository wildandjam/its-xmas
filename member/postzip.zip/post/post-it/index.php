<?php require('../../../res/meta.php'); ?>
<?php require('../../../res/membercheck.php'); ?>
<title>Post options | It's Christmas</title>
<script src="http://jwpsrv.com/library/P1ehQj67EeS+YSIACyaB8g.js"></script>
<script type="text/javascript">
$(function(){
    jwplayer("video").setup({
        file: "<?php echo $_REQUEST['url']; ?>",
        width: 640,
        height: 360
    });
});
</script>
</head>
<body>
<?php require('../../../res/headnav.php'); ?>
<div id="container">
    <div class="content">   
        <?php 
			$postType = $_REQUEST['postType'];
			if ($postType == "text"){
				$textContent = $_REQUEST['textContent'];	
			}
			$user = $_REQUEST['user'];
			$url = $_REQUEST['url'];
			$image = $_REQUEST['image'];
		?>
		<div class="postIt">
			<form action="/process/post.php" method="post">
				<input type="hidden" name="user" id="user" value="<?php echo $user; ?>" />
				<input type="hidden" name="url" id="url" value="<?php echo $url; ?>" />
				<input type="hidden" name="image" id="image" value="<?php echo $image; ?>" />
                <input type="hidden" id="textContent" name="textContent" value="<?php echo $textContent; ?>" />
                <input type="hidden" id="postType" name="postType" value="<?php echo $postType; ?>" />
				<?php if ($postType == "text"){ ?>
                	<div id="textContentContainer">
						<?php echo $textContent; ?>
                        
                        
                    </div>
                <?php } else if ($postType == "video"){?>
					<div id="video"></div>
                    
                    
                                   
                <?php } else { ?>
	                <img src="<?php echo $image; ?>" class="chosenImage"/>
                <?php }?>
				
				<input type="text" name="title" id="title" placeholder="Enter title here" />
                <textarea id="description" name="description" placeholder="Description"></textarea>
				<div class="postRow">
				<span>Category: </span>
					<?php 
						$getCats = true;
						require('../../../res/category.php');
						$getCats = false;

					?>
				</div>
				<div class="postRow">
					<?php
						$listQuery = mysqli_query($connect, "SELECT * FROM collections WHERE userID = '$user'");
						$listRows = mysqli_num_rows($listQuery);
						
						if ($listRows != '0'){
							$listHTML = "<span>Add to collection:</span>";
							$listHTML .= "<select name=\"list\"><option value=\"0\">Choose list</option>";
							
							while($listR = mysqli_fetch_array($listQuery)){
								$listHTML .= "<option value=\"" . $listR['listID'] . "\">" . $listR['listName'] . "</option>";
							
							}						
							$listHTML .= "</select>";
							echo $listHTML;
						}
					?>
				</div>
				<div class="postRow">
					<span>
						Post privacy: 
					</span>
					<select name="privacy" id="privacy">
						<option value="public">Public</option>
						<option value="private">Private</option>
					</select>
				</div>
				<input id="postit" name="postit" type="submit" style="clear:both;" value="Post" />
				
				
				
			
			
			</form>
		</div>
	</div>
	<?php require('../../../res/sidebars.php'); ?>
</div>
</body>
</html>
