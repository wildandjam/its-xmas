<?php 
	$postType = $_REQUEST['postType'];
	

require('../../../res/meta.php');
require('../../../res/membercheck.php'); ?>
<script src="http://jwpsrv.com/library/P1ehQj67EeS+YSIACyaB8g.js"></script>
<script type="text/javascript">
$(function(){
    jwplayer("video").setup({
        file: "<?php echo $_REQUEST['url']; ?>",
        width: 640,
        height: 360
    });
});
</script>
</head>
<body>
<?php require('../../../res/headnav.php'); ?>
<div id="container">
	<h1>Select an image</h1>
       <?php 
	   		print_r($_REQUEST);

		?>
        <div id="video">
        </div>
		

	<?php require('../../../res/sidebars.php'); ?>
</div>
</body>
</html>
