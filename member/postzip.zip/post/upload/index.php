<?php 
	require('../../../res/meta.php');
	require('../../../res/membercheck.php'); ?>
<title>Upload an image | It's Christmas</title> 
</head>
<body>
<?php require('../../../res/headnav.php'); ?>
<div id="container">
    <div class="content">
        <h1>What image you like to upload?</h1>
        <?php
//phpinfo();
?>
        <br />
        <form method="post" action="/member/post/post-it/" name="postitem" id="postitem" enctype="multipart/form-data">
            <input type="hidden" value="<?php echo $id; ?>" name="user" id="user" />
			<input type="file" name="filename" id="filename" accept="image/jpeg, image/png, image/gif" />
            <!--<input id="submitone" name="submitone" type="submit" style="clear:both;" value="Next >" />-->
            <input hidden="hidden" id="image" name="image" value="" />
            <input hidden="hidden" id="url" name="url" value="0"/>
            <input hidden="hidden" id="postType" name="postType" value="image"/>
            <button style="display:none;">Upload</button>
            <img src="/images/loading.gif" alt="Loading Image" style="display:none;" class="loadingGif"/>
        </form>
	</div>
    <script src="/js-upload/vendor/canvas-to-blob.min.js"></script>
	<script src="/js-upload/resize.js"></script>
    <script src="/js-upload/app.js"></script>
	<?php require('../../../res/sidebars.php'); ?>
</div>
</body>
</html>
