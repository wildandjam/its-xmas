<?php
require('../res/connect.php');
$postID = $_REQUEST['postID'];
$userID = $_REQUEST['userID'];
$commentTitle = mysqli_real_escape_string($connect, $_REQUEST['commentTitle']);
$commentContent = mysqli_real_escape_string($connect, $_REQUEST['commentContent']);
$commentReply = $_REQUEST['commentReply'];
$date = date("Y-m-d H:i:s");

$commentCheck = mysqli_query($connect, "SELECT * FROM comments WHERE userID = '$userID' AND commentTitle = '$commentTitle' AND commentDate = '$commentDate'");
$commentCheckCount = mysqli_num_rows($commentCheck);
if ($commentCheckCount == 0){
	$commentAdd = mysqli_query($connect, "INSERT INTO comments VALUES ('','$postID','$userID','$commentTitle','$commentContent','$date','$commentReply','0','0')");
	if ($commentAdd){
		 	header("location:/post/?id=".$postID."&status=success");
	} else {
	header("location:/post/?id=".$postID."&status=fail");
	}
} else {
	header("location:/post/?id=".$postID."");
}
?>