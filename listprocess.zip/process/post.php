<?php 
	require ('../res/meta.php');
	require ('../res/membercheck.php');
	require('../res/connect.php');
	$user = $_REQUEST['user'];
	$url = $_REQUEST['url'];
	$image = $_REQUEST['image'];
	$category = $_REQUEST['category'];
	$title = mysqli_real_escape_string($connect, $_REQUEST['title']);
	$type = $_REQUEST['postType'];
	$width = "0";
	$height = "0";
	$privacy = $_REQUEST['privacy'];
	$tags = $_REQUEST['tags'];
	$desc = mysqli_real_escape_string($connect, $_REQUEST['description']);
	$textContent = mysqli_real_escape_string($connect, $_REQUEST['textContent']);
	
	if ($type != "text"){
		if ($user && $url && $image){
			if ($privacy == "public"){
				$postPrivacy = 0;
			} else {
				$postPrivacy = 1;
			}
		} else {
			header('location: /member/post/'); 
		}
	}
	if ($category && $category != "Select category"){
		$category = 33;
	}
	
	echo $user . "<br />";
	echo $url  . "<br />";
	echo $image  . "<br />";
	echo $category  . "<br />";
	echo $title . "<br />";
	echo $type . "<br />";
	echo $privacy  . "<br />";
	echo $tags  . "<br />";
	echo $desc  . "<br />";
	echo $textContent  . "<br />";
	
	//duplication tests
	if ($image != ""){
		if (mysqli_num_rows($linkposted) > 1){
			header("location: /member/post/post-it/?url=$url&image=$image&desc=$desc&title=$title&type=$tye&status=already");	
		}
	} else if ($textContent != ""){
		$linkposted = mysqli_query($connect, "SELECT * FROM posts WHERE userID = '$user' AND postImage = '$textContent'");
		if (mysqli_num_rows($linkposted) > 1){
			header("location: /member/post/post-it/?url=$url&image=$textContent&desc=$desc&title=$title&type=$tye&status=already");	
		}
	}
	 echo "trial";
	
	$date = date("Y-m-d H:i:s");
	if ($type == "text"){
		$querypostmysql = "INSERT INTO posts VALUES ('',0,'$user','$category','$type','$title','$desc','$url','$textContent','$width','$height','$date','0','0','0','$postPrivacy','0')";
	} else {
		$querypostmysql =  "INSERT INTO posts VALUES ('',0,'$user','$category','$type','$title','$desc','$url','$image','$width','$height','$date','0','0','0','$postPrivacy','0')";
	}
	$querypost = mysqli_query($connect,$querypostmysql);
	die();
	if ($querypost) {
		$getPostQuery = "SELECT * FROM posts WHERE userID = '$user' AND postTitle = '$title' AND postDate = '$date'";
		echo $getPostQuery;
		$getPost = mysqli_query($connect,$getPostQuery);
		$getPostRows = mysqli_num_rows($getPost);
		
		if ($getPostRows == 1){
			while($postRow = mysqli_fetch_assoc($getPost)) {
				$postID = $postRow['postID'];
				header('location: /post/?id=' . $postID , "&status=successful");					
			}
		} else {
			header("location: /user/?uid" . $user);	
		}
	} else {
		if ($type == "text"){
			header("location: /member/post/post-it/?url=$url&image=$textContent&desc=$desc&title=$title&type=$tye&status=error");	
		} else {
			header("location: /member/post/post-it/?url=$url&image=$image&desc=$desc&title=$title&type=$tye&status=error");	
		}
	}

?>	