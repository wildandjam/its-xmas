<?php
	require('../res/user.php');
	
	if ($id){
		$listID = $_REQUEST['listID'];
		$postID = $_REQUEST['postID'];
	
		$checkCollection = mysqli_query($connect, "SELECT * FROM collectionposts WHERE postID = '$postID' AND userID = '$id' AND listID = '$listID'");
		
		if (mysqli_num_rows($checkCollection) > 0){
			return false;	
		} else {
			$listQuery = mysqli_query($connect, "INSERT INTO collectionposts VALUES ('','$listID','$id', '$postID')") or die(mysqli_error($connect));
		}
	}
?>